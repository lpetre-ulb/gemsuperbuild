#! /bin/bash

echo "0"
sleep 1
echo "daq"
sleep 1
echo "status"
sleep 1
echo "quit"
sleep 1
echo "exit"
sleep 1
echo "-1"
