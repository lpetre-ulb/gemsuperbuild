#! /usr/bin/python

srpName = raw_input( "ScriptName: " );
size = raw_input( "Reg 0x18 size: " );

