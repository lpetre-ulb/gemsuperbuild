
Directory addrTableTools contains tools for maintaining and manipulating
address tables.

  parse_xml_table.pl  	   Converts XML address table to CSV for spreadsheet view/edit
  csv_to_xml.pl            Converts CSV address table back to XML

  AMC13XG_T1_v0x4002.csv   Current top-level Kintex address table
  AMC13XG_T2_v0x21.csv     Current top-level Spartan address table
  AMCCounters.csv          Current address table for AMC counters

  AMC13XG_T1_v0x00fb.csv   Special Kintex table for DAQLDC test firmware

