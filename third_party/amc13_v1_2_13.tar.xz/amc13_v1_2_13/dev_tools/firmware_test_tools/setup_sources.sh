AMC13Tool2.exe -c 79/c -X random_source_setup.amc
AMC13Tool2.exe -c 160/c -X random_source_setup.amc
AMC13Tool2.exe -c 322/c -X random_source_setup.amc
AMC13Tool2.exe -c 111/c -X random_source_setup.amc
AMC13Tool2.exe -c 258/c -X random_source_setup.amc
