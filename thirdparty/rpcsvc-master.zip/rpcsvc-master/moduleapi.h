#ifndef __MODULEAPI_H
#define __MODULEAPI_H

#include "wiscRPCMsg.h"
#include "ModuleManager.h"
#include "LogManager.h"
#include "LockTools.h"
using namespace wisc;

#endif
